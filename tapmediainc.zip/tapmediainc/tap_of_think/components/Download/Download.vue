<template>
    <section class="section download-area ptb_100">
        <!-- Shapes Container -->
        <div class="shapes-container d-none d-sm-block">
            <div class="shape-2"></div>
            <div class="shape-3"></div>
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-md-10 col-lg-8">
                    <!-- Download Text -->
                    <div class="download-text text-center">
                        <h2>Download App</h2>
                        <p class="my-3">To start using Yoush, download the app from your device's app store. For Android users, open the Google Play Store, search for "Yoush Private Messenger," and tap "Install." iOS users should open the App Store, search for "Yoush Private Messenger," and tap "Get." Once installed, open the app. If prompted, grant necessary permissions for optimal functionality. Congratulations, you've successfully downloaded Yoush and are ready to proceed with registration and setup.</p>
                        <!-- Store Buttons -->
                        <div class="button-group store-buttons">
                            <a href="#" class="btn btn-bordered">
                                <i class="icofont icofont-brand-android-robot dsp-tc"></i>
                                <p class="dsp-tc">GET IT ON
                                    <br> <span>Google Play</span></p>
                            </a>
                            <a href="#" class="btn btn-bordered">
                                <i class="icofont icofont-brand-apple dsp-tc"></i>
                                <p class="dsp-tc">AVAILABLE ON
                                    <br> <span>Apple Store</span></p>
                            </a>
                            <a href="#" class="btn btn-bordered d-none d-lg-inline-block">
                                <i class="icofont-brand-windows dsp-tc"></i>
                                <p class="dsp-tc">AVAILABLE ON
                                    <br> <span>Windows Store</span></p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {

}
</script>

<style>

</style>