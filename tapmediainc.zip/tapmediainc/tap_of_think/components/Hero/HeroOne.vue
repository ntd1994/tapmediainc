<template>
    <section id="home" class="section welcome-area d-flex align-items-center">
        <div class="container">
            <div class="row align-items-center">
                <!-- Welcome Intro Start -->
                <div class="col-12 col-md-7 col-lg-6">
                    <div class="welcome-intro">
                        <h1>TAP</h1>
                        <h1 class="fw-3 mt-2 mt-sm-3">MEDIA INC</h1>
                        <h3 class="fw-3 mt-2 mt-sm-3">Technology - Approach - Platform</h3>
                        <p class="my-3">    Established in 2021, TAP Media Inc, situated on Spring Flower Ave in Las Vegas, is a leading global corporation in technology and media, embodying the core values encapsulated by ours acronym: Technology - Approach - Platform, driving us towards our ultimate desire: to become a global hub for trustworthy information and secure communication. Our company offering the following innovative products</p>
                        <p class="my-3">Tap News: An online newspaper dedicated to delivering the fastest, most valuable, and accurate information. As a bridge connecting you to the world, our aim is to be the go-to source for news, keeping you well-informed and engaged.</p>
                        <p class="my-3">Yoush Secure Chat Application: A distinctive platform providing secure and private text, voice, and video conversations. With Yoush, we not only facilitate communication but also ensure peace of mind and security with every connection, fostering trust and reliability.</p>
                        <p>Join Tap Media Inc, where Technology, Approach, and Platform converge for a creative and informative online space. Together, we are building a future where information empowers and connections are secure. Elevate your experience with us today!</p>
                        <div class="button-group">
                            <a href="#" class="btn btn-bordered"><span>Download</span></a>
                            <a href="#" class="btn btn-bordered d-none d-sm-inline-block">Read More</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-5 col-lg-6">
                    <!-- Welcome Thumb -->
                    <div class="welcome-thumb text-center" data-aos="fade-left" data-aos-delay="500" data-aos-duration="1000">
                        <img src="assets/img/homepage_hero.png" class="rounded-lg" alt="">
                    </div>
                    <!-- Video Icon -->
                    <div class="video-icon d-none d-lg-block">
                        <a class="play-btn" data-fancybox href="https://www.youtube.com/watch?v=hs1HoLs4SD0">
                            <i class="icofont-ui-play"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {

}
</script>

<style>

</style>