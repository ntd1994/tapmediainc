<template>
    <div class="blog">
      <ScrollupSection />
      <div class="all-area">
        <section id="blog" class="section blog-area ptb_50">
              <div class="container">
                  <div class="" style="max-with: 100%; margin:auto">
                      <div class="col-12 col-lg-9" style="max-with:80%; margin: auto">
                          <!-- Single Blog Details -->
                          <article class="single-blog-details">
                              <!-- Blog Content -->
                              <div class="blog-content appo-blog">
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Introduction</a></h3>
                                      <p class="d-none d-sm-block mb-3">We create technologies and services to help people connect with each other safely and securely with chat content. These terms govern your use of our application. We or other third parties cannot access messages and calls because they are always end-to-end encrypted, private, and secure.</p>
                                      <p class="d-none d-sm-block">There is no charge for you to use Yoush or other products and services covered by these Terms.</p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Privacy Policy</a></h3>
                                      <p class="d-none d-sm-block mb-3">You can count on our loss of security. Any data (calls, messages) you send via Yoush is encrypted. Yoush uses modern security and End-To-End encryption to provide secure private messaging and Internet calling to users worldwide.</p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
																		<h3 class="blog-title py-2 py-sm-3"><a href="#">Terms of Service</a></h3>
																		<p class="d-none d-sm-block mb-3">By subscribing to You, you accept our privacy policy:</p>
																		<ul class="mb-3">
																			<li>We strictly prohibit the use of Yoush to be deceptive, malicious, or intended to abuse or misuse networks, devices, or personal data.</li>
																			<li>Do not use our service to send spam and mass messaging to users.</li>
																			<li>Do not promote violence on publicly viewable Yoush channels, shows, etc.</li>
																			<li>Posting illegal pornography on publicly viewable Yoush channels, shows, etc. is strictly prohibited.</li>
																		</ul>
																		<p class="d-none d-sm-block mb-3">We reserve the right to update these Terms of Service at a later time</p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Our services</a></h3>
                                      <p class="d-none d-sm-block mb-3">Target audience: Citizens of all countries 13 years of age or older.</p>
                                      <p class="d-none d-sm-block mb-3">Apps: Yoush is committed to protecting user privacy and providing a safe and secure environment for our users. Download and install software updates to use new features.</p>
                                      <p class="d-none d-sm-block mb-3">User Data:Yoush is committed not to share, sell or monetize users’ personal data or information in any way.</p>
                                      <p class="d-none d-sm-block mb-3">User Support: We will assist you when you face any Yoush problem.</p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Yoush Terms and Conditions of Use</a></h3>
                                      <p class="d-none d-sm-block mb-3">Terms of Use: When using Yoush you must abide by our Terms and policies. Please read the terms and policies carefully so that in case you violate any of them, we will disable your account.</p>
                                      <p class="d-none d-sm-block mb-3">Fair Use: Before using the software you agree to use our Services only for lawful purposes. You must not violate the following:</p>
																			<ul class="mb-3">
																				<li>Violate Yoush’s rights, including privacy, publicity, intellectual property, or other proprietary rights;</li>
																				<li>Mass messaging, spamming, and automated messaging are not allowed</li>
																			</ul>
                                      <p class="d-none d-sm-block mb-3">Abuse and harm Yoush: You may not (or assist others) with phishing, spam, and other types of abuse, attack, or harm Yoush, our Services, or the system, such as accessing, using, or otherwise harming Yoush. use, modify, distribute, transfer or otherwise exploit our Services in an unauthorized manner.</p>
                                      <p class="d-none d-sm-block mb-3">Device Transfer: When you switch to Yoush on another device, Yoush on the old device stops working.</p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Your rights to Yoush</a></h3>
                                      <p class="d-none d-sm-block mb-3">Your Ownership: Under applicable data protection laws, in certain circumstances, you have rights regarding your personal data. You have the right to (1) delete or modify your personal data; (2) You can control how your data is used (e.g. delete synced contacts) in Settings > Privacy & security; (3) complain to national data protection authorities about our processing of your personal data.</p>
                                      <p class="d-none d-sm-block mb-3">Availability of our services: Our services may be interrupted, including with maintenance, upgrades, or network or equipment failures. We may discontinue some or all of our Services, including certain features and support for certain devices and platforms, at any time.</p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Yoush rights</a></h3>
                                      <p class="d-none d-sm-block mb-3">We own all copyrights, trademarks, and logos related to the services we provide to you. For questions about related copyrights please contact <a href="mailto:contact@tapofthink.com">contact@tapofthink.com.</a></p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">End of Terms</a></h3>
                                      <p class="d-none d-sm-block mb-3">By default, this provision will automatically end if you stop using your account will be deleted along with all messages, media, contacts, and any other piece of data. We may disable your account if you violate the text of our Terms of Service or create harm, risk, or legal exposure to Yoush.</p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Overview</a></h3>
                                      <p class="d-none d-sm-block mb-3">We may update the Terms of Service at any time. The update time will be clearly noted by us. If you wish to continue using our services you must accept the updated terms of service. You will comply with all terms. Our Terms cover the entire agreement between you and Yoush.</p>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Information you provide</a></h3>
                                      <p class="d-none d-sm-block mb-3">Account: When creating a Yoush account, you register with your phone number. You can optionally add additional information to your accounts, such as your profile name and profile picture, which is end-to-end encrypted. If you want to delete your account, you can do so by removing the app from your device. Deleting your account will delete all your messages, media, contacts, and any other piece of data.</p>
                                      <p class="d-none d-sm-block mb-3">Phone number: Phone number as a unique identifier for you to easily switch from SMS and other messaging apps.</p>
                                      <p class="d-none d-sm-block mb-3">Messages: Yoush cannot decrypt or access the contents of your messages or calls. Chats use end-to-end encryption. This means that all data is encrypted with a key that only you and the recipient know. There is no way for us or anyone else without direct access to your device to learn what was sent in those messages.</p>
                                      <p class="d-none d-sm-block mb-3">Self-destructing messages: Messages may be asked to self-destruct. As soon as a message is read. When the timer expires, both devices participating in the secret conversation are instructed to delete the message (photo, video, etc.). Media with short hours (less than one minute) is displayed with blurred preview. Timers are activated when they are viewed</p>
                                      <p class="d-none d-sm-block mb-3">Contacts: Information from contacts on your device can be cryptographically hashed and transmitted to a server to determine which of your contacts have been registered. Yoush may in its sole discretion discover which contacts in your contact book are Yoush users, using a service designed to protect the privacy of your contacts.</p>
                                      <p class="d-none d-sm-block mb-3">Manage your information: You can manage your personal information in Yoush.</p>
                                      <p class="d-none d-sm-block mb-3">Other circumstances where You may need to share your data</p>
																			<ul class="mb-3">
																				<li>Comply with government regulations (eg: If Yoush receives a court order confirming you are a terrorist suspect, we may disclose your phone number to the relevant authorities.)</li>
																				<li>Protection from harm to Yoush rights, property, or safety.</li>
																			</ul>
                                  </div>
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                      <h3 class="blog-title py-2 py-sm-3"><a href="#">Contact us</a></h3>
                                      <p class="d-none d-sm-block mb-3">If you have questions about our Policy and Terms of Service, please contact us at <a href="mailto:contact@tapofthink.com">contact@tapofthink.com.</a></p>
                                  </div>
                              </div>
                          </article>
                      </div>
                  </div>
              </div>
          </section>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">

  </script>
  
  <style scoped>
		ul li {
			list-style-type: disc;
			margin-left: 14px;
			margin-bottom: 12px;
		}
		a[href^="mailto:"] {
			color: blue;
			text-decoration: underline;
		}
  </style>