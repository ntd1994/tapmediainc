<template>
    <div class="blog">
      <ScrollupSection />
      <div class="all-area">
        <section id="blog" class="section blog-area ptb_50">
              <div class="container">
                  <div class="" style="max-with: 100%; margin:auto">
                      <div class="col-12 col-lg-9" style="max-with:80%; margin: auto">
                          <!-- Single Blog Details -->
                          <article class="single-blog-details">
                              <!-- Blog Content -->
                              <div class="blog-content appo-blog">
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                    <p class="mb-3">
                                        If Yoush is blocked in your country, you can use a proxy to get started with and continue using Yoush. All traffic remains opaque to the proxy operator.
                                    </p>
                                    <h5 class="py-2 py-sm-3">How to find a Yoush proxy address</h5>
                                    <p class="mb-3">
                                        There are a few ways to find a Yoush proxy address:
                                    </p>
                                    <ul class="mb-3">
                                        <li>
                                            <strong>Search Twitter or other social media platforms for the hashtag #IRanASignalProxy.</strong> This hashtag is often used by people who are sharing Yoush proxy addresses.
                                        </li>
                                        <li>
                                            <strong>Get a link or scan a QR code from your friends and family.</strong> If you know someone who is using a Yoush proxy, they can share the address with you.
                                        </li>
                                        <li>
                                            <strong>Set up your own Signal proxy.</strong> This requires a server with ports 80 and 443 available and a domain name (or subdomain) that points to the server’s IP address. Instructions on how to set up a Yoush proxy can be found on the Yoush blog or GitHub.
                                        </li>
                                    </ul>
                                    <h5 class="py-2 py-sm-3">What happens if my proxy is blocked?</h5>
                                    <p class="mb-3">
                                        If your Yoush proxy is blocked, you will see an error message in the app and you will not be able to send or receive messages. To fix this, you can try changing your proxy address to one that is not blocked.
                                    </p>
                                  </div>
                              </div>
                          </article>
                      </div>
                  </div>
              </div>
          </section>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">

  </script>
  
  <style scoped>
    ul li {
        list-style-type: disc;
        margin-left: 14px;
        margin-bottom: 12px;
    }
    ol li {
        list-style-type: decimal;
        margin-left: 14px;
        margin-bottom: 12px;
    }
    a[href^="mailto:"] {
        color: blue;
        text-decoration: underline;
    }
  </style>
