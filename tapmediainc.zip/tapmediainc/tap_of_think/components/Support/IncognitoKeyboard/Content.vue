<template>
    <div class="blog">
      <ScrollupSection />
      <div class="all-area">
        <section id="blog" class="section blog-area ptb_50">
              <div class="container">
                  <div class="" style="max-with: 100%; margin:auto">
                      <div class="col-12 col-lg-9" style="max-with:80%; margin: auto">
                          <!-- Single Blog Details -->
                          <article class="single-blog-details">
                              <!-- Blog Content -->
                              <div class="blog-content appo-blog">
                                  <!-- Blog Details -->
                                <div class="blog-details">
                                  <p data-sourcepos="1:1-1:65"><strong>Yoush Incognito Keyboard: What is it and why should you care?</strong></p>
                                  <p data-sourcepos="3:1-3:392">Yoush Incognito Keyboard is a feature that allows you to enable an optional keyboard privacy flag that is provided by the Android operating system. This means that your keyboard will not learn from the input you type, and entries will not be remembered by your keyboard’s dictionary. This can help to protect your privacy and prevent your keyboard from being used to track your typing habits.</p>
                                  <p data-sourcepos="5:1-5:100">To enable Yoush Incognito Keyboard, go to <strong>Yoush Settings</strong> &gt; <strong>Privacy</strong> &gt; <strong>Incognito Keyboard</strong>.</p>
                                  <p data-sourcepos="7:1-7:84">Here are some of the things you may notice when you enable Yoush Incognito Keyboard:</p>
                                  <ul data-sourcepos="9:1-12:0">
                                    <li data-sourcepos="9:1-9:145">Your keyboard may not work as well as it did before. This is because it will not be able to learn from your typing habits and make predictions.</li>
                                    <li data-sourcepos="10:1-10:105">You may notice more typos. This is because your keyboard will not be able to autocorrect your mistakes.</li>
                                    <li data-sourcepos="11:1-12:0">Your keyboard may not be able to suggest words or phrases that you have typed in the past.</li>
                                  </ul>
                                  <p data-sourcepos="13:1-13:294">It is important to note that keyboards and IME’s can ignore Android’s Incognito Keyboard flag. This means that there is no guarantee that your keyboard will not track your typing habits, even if you have enabled Yoush Incognito Keyboard. It is important to use a keyboard or IME that you trust.</p>
                                </div>
                              </div>
                          </article>
                      </div>
                  </div>
              </div>
          </section>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">

  </script>
  
  <style scoped>
  p {
    margin-bottom: 20px;
  }
		ul li {
			list-style-type: disc;
			margin-left: 14px;
			margin-bottom: 12px;
		}
		a[href^="mailto:"] {
			color: blue;
			text-decoration: underline;
		}
  </style>
