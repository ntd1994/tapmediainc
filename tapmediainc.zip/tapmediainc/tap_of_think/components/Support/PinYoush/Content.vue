<template>
    <div class="blog">
      <ScrollupSection />
      <div class="all-area">
        <section id="blog" class="section blog-area ptb_50">
              <div class="container">
                  <div class="" style="max-with: 100%; margin:auto">
                      <div class="col-12 col-lg-9" style="max-with:80%; margin: auto">
                          <!-- Single Blog Details -->
                          <article class="single-blog-details">
                              <!-- Blog Content -->
                              <div class="blog-content appo-blog">
                                  <!-- Blog Details -->
                                  <div class="blog-details">
<!--                                    <h3 class="blog-title py-2 py-sm-3">Signal messages, images, files, and other content are kept on your device.</h3>-->
                                    <p class="blog-title">
                                      <strong>
                                        A Yoush PIN is an alphanumeric code or code used to help you recover your account if you lose or move your device. PIN codes also support features such as non-phone number based identifiers and can be used as registration keys.
                                      </strong></p>
                                    <img src="assets/img/PIN.jpg" alt="" class="blog-title py-2 py-sm-3">
                                    <p class="blog-title py-2 py-sm-3">
                                      <strong>
                                        Advantages of Yoush PIN:</strong></p>
                                    <ul class="mb-3">
                                     <li>Helps you recover your account if you lose or move your device</li>
                                     <li>Supports non-phone number based identifiers</li>
                                     <li>Can be used as a registration key</li>
                                     <li>Your data is stored securely, with no server side involved</li>
                                    </ul>
                                    <p class="blog-title py-2 py-sm-3">
                                      <strong>Disadvantages of Yoush PIN:</strong></p>
                                    <ul class="mb-3">
                                      <li>Chats cannot be recovered</li>
                                      <li>Yoush doesn’t know your PIN so it can’t reboot or restore it for you</li>
                                      <li>If you forget your PIN and have activated the registration lock, you will not be able to access your account for up to 7 days</li>
                                    </ul>
                                    <p class="blog-title py-2 py-sm-3">
                                      <strong>Notes when using Yoush PIN:</strong></p>
                                    <ul class="mb-3">
                                      <li>Remember your PIN or store it in a safe place</li>
                                      <li>If you forget your PIN, you can reset it using your phone number</li>
                                      <li>If you have enabled a registration key, you will need to enter your PIN to access your account</li>
                                    </ul>
                                    <p class="blog-title py-2 py-sm-3">
                                      <strong>How to create a Yoush PIN:</strong></p>
                                    <ul class="mb-3">
                                      <li>You can create a PIN when you sign up for a Yoush account or in your account settings. To create a PIN, follow these steps:</li>
                                      <li> Open the Yoush app.</li>
                                      <li> Tap the profile icon.</li>
                                      <li> Click Settings.</li>
                                      <li> Tap Account.</li>
                                      <li> Tap Create PIN.</li>
                                      <li> Enter your PIN.</li>
                                      <li> Re-enter your PIN to confirm.</li>
                                    </ul>
                                  </div>
                              </div>
                          </article>
                      </div>
                  </div>
              </div>
          </section>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">

  </script>
  
  <style scoped>
		ul li {
			list-style-type: disc;
			margin-left: 14px;
			margin-bottom: 12px;
		}
		a[href^="mailto:"] {
			color: blue;
			text-decoration: underline;
		}
  </style>
