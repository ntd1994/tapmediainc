<template>
    <div class="blog">
      <ScrollupSection />
      <div class="all-area">
        <section id="blog" class="section blog-area ptb_50">
              <div class="container">
                  <div class="" style="max-with: 100%; margin:auto">
                      <div class="col-12 col-lg-9" style="max-with:80%; margin: auto">
                          <!-- Single Blog Details -->
                          <article class="single-blog-details">
                              <!-- Blog Content -->
                              <div class="blog-content appo-blog">
                                  <!-- Blog Details -->
                                  <div class="blog-details">
<!--                                    <h3>Signal messages, images, files, and other content are kept on your device.</h3>-->
                                    <p><strong>Yoush profile</strong></p>

                                    <p>Your Yoush Profile is a name and picture that you set up within the app. It is shown alongside your phone number and helps people to know who’s messaging them. Your profile information is end-to-end encrypted, so the Signal service cannot see it.</p>
                                      <p data-sourcepos="5:1-5:33"><strong>Is a Yoush Profile required?</strong></p>
                                      <p>Yes, sharing your profile is required to continue chats.</p>
                                      <p data-sourcepos="9:1-9:34"><strong>Who can see my Yoush Profile?</strong></p>
                                      <p><span class="citation-0">Your Yoush Profile is automatically shared with:</span></p>
                                      <ul data-sourcepos="13:1-17:0">
                                        <li data-sourcepos="13:1-13:50"><span class="citation-0">Any contacts you have saved in your address book</span></li>
                                        <li data-sourcepos="14:1-14:57"><span class="citation-0 citation-end-0">Any people or groups in conversations you create</span></li>
                                        <li data-sourcepos="15:1-15:44">Any people or groups you explicitly accept</li>
                                        <li data-sourcepos="16:1-17:0">Any groups you are added to by someone that you had previously shared your profile with</li>
                                      </ul>
                                      <p data-sourcepos="18:1-18:39"><strong>How is my Yoush Profile displayed?</strong></p>
                                      <p>Your Yoush Profile is displayed alongside your existing phone number. This makes conversations feel more personal and group threads less confusing.</p>
                                      <p data-sourcepos="22:1-22:20"><strong>Message Requests</strong></p>
                                      <p><span class="citation-1 citation-end-1">Message Requests give you the option to block, delete, or accept messages from somebody who is trying to get in touch with</span> you.</p>
                                      <p data-sourcepos="26:1-26:173">For individual conversations, you get to see the name (and photo) of the person who’s trying to message you. This helps you to decide whether or not to accept their request.</p>
                                      <p>For group conversations, you also get to see the name and photo of the person who is trying to add you. This helps you to avoid joining groups that you don’t want to be in.</p>
                                      <p data-sourcepos="30:1-30:26"><strong>What happens when I…</strong></p>
                                      <ul data-sourcepos="32:1-49:0">
                                        <li data-sourcepos="32:1-35:55"><strong>Block a contact</strong>
                                          <ul data-sourcepos="33:5-35:55">
                                            <li data-sourcepos="33:5-33:81">The contact will not be able to see changes to your profile name and photo.</li>
                                            <li data-sourcepos="34:5-34:59">You will not receive notifications from this contact.</li>
                                            <li data-sourcepos="35:5-35:55">This contact will not know you have blocked them.</li>
                                          </ul>
                                        </li>
                                        <li data-sourcepos="36:1-40:42"><strong>Block a group</strong>
                                          <ul data-sourcepos="37:5-40:42">
                                            <li data-sourcepos="37:5-37:68">The group will not be able to see your profile name and photo.</li>
                                            <li data-sourcepos="38:5-38:73">You will leave the group. The group is notified that you have left.</li>
                                            <li data-sourcepos="39:5-39:79">You will not receive any more messages or updates from the blocked group.</li>
                                            <li data-sourcepos="40:5-40:42">You cannot be re-added to the group.</li>
                                          </ul>
                                        </li>
                                        <li data-sourcepos="41:1-43:68"><strong>Delete a conversation</strong>
                                          <ul data-sourcepos="42:5-43:68">
                                            <li data-sourcepos="42:5-42:39">The conversation will be deleted.</li>
                                            <li data-sourcepos="43:5-43:68">If the conversation is a group, you will also leave the group.</li>
                                          </ul>
                                        </li>
                                        <li data-sourcepos="44:1-49:0"><strong>Accept a message request</strong>
                                          <ul data-sourcepos="45:5-49:0">
                                            <li data-sourcepos="45:5-45:78">The person who sent the request will be able to see your Yoush profile.</li>
                                            <li data-sourcepos="46:5-46:109">The person who sent the request will be able to receive read receipts, if enabled on both your devices.</li>
                                            <li data-sourcepos="47:5-47:74">The person who sent the request will be able to message or call you.</li>
                                            <li data-sourcepos="48:5-49:0">The person who sent the request will be added to your Yoush contact list.</li>
                                          </ul>
                                        </li>
                                      </ul>
                                      <p data-sourcepos="50:1-50:14"><strong>Conclusion</strong></p>
                                      <p>Your Yoush Profile and Message Requests help you to control who can contact you and what information they can see. This is important for your privacy and security.</p>
                                    </div>
                              </div>
                          </article>
                      </div>
                  </div>
              </div>
          </section>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">

  </script>
  
  <style scoped>
    p {
      margin: 20px 0;
    }
		ul li {
			list-style-type: disc;
			margin-left: 14px;
			margin-bottom: 12px;
		}
		a[href^="mailto:"] {
			color: blue;
			text-decoration: underline;
		}
  </style>
