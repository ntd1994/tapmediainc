<template>
    <section class="start-free-area">
        <div class="container">
            <div class="col-12">
                <!-- Start Free Content -->
                <div class="start-free-content d-flex flex-wrap align-items-center justify-content-center justify-content-lg-between shadow-lg" data-aos="fade-up">
                    <!-- Start Free Content -->
                    <div class="start-free-text">
                        <h2 class="mb-2">Don’t have Yoush?</h2>
                        <a href="/download" class="btn btn-primary"><span>Join group</span></a>
                    </div>
                    <!-- Start Free Button -->
                    <div class="start-free-btn mt-4 mt-lg-0">
                        <a href="/download" class="btn btn-bordered"><span>Get it here!</span></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {

}
</script>

<style>

</style>