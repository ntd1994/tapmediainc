<template>
    <div class="blog">
      <ScrollupSection />
      <div class="all-area">
        <section id="blog" class="section blog-area ptb_50">
              <div class="container">
                  <div class="" style="max-with: 100%; margin:auto">
                      <div class="col-12 col-lg-9" style="max-with:80%; margin: auto">
                          <!-- Single Blog Details -->
                          <article class="single-blog-details">
                              <!-- Blog Content -->
                              <div class="blog-content appo-blog">
                                  <!-- Blog Details -->
                                  <div class="blog-details">
                                    <ul class="mb-3">
                                        <li>Yoush provides private groups for all platforms, but insecure MMS groups on Android.</li>
                                        <li>A Yoush group is built on top of the private group system technology and the Yoush service has no record of your group memberships, group titles, group avatars, or group attributes.</li>
                                        <li>Group features include:</li>
                                        <ul class="pl-4">
                                            <li>Invite via a group link or QR-code</li>
                                            <li>Mentions</li>
                                            <li>Group descriptions</li>
                                            <li>Admin controls to remove a member from the group</li>
                                            <li>Admin controls of who can edit group info and the disappearing message timer</li>
                                            <li>Admin controls of who can send messages and start calls</li>
                                            <li>Optional admin approval for members joining by a group link</li>
                                            <li>Size limit of 1000</li>
                                        </ul>
                                        <li>See also:</li>
                                        <ul class="pl-4">
                                            <li>Manage a group</li>
                                            <li>Leave a group</li>
                                            <li>Group troubleshooting</li>
                                        </ul>
                                    </ul>
                                  </div>
                              </div>
                          </article>
                      </div>
                  </div>
              </div>
          </section>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">

  </script>
  
  <style scoped>
		ul li {
			list-style-type: disc;
			margin-left: 14px;
			margin-bottom: 12px;
		}
		a[href^="mailto:"] {
			color: blue;
			text-decoration: underline;
		}
  </style>