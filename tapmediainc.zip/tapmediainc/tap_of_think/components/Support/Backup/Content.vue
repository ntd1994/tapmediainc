<template>
    <div class="blog">
      <ScrollupSection />
      <div class="all-area">
        <section id="blog" class="section blog-area ptb_50">
              <div class="container">
                  <div class="" style="max-with: 100%; margin:auto">
                      <div class="col-12 col-lg-9" style="max-with:80%; margin: auto">
                          <!-- Single Blog Details -->
                          <article class="single-blog-details">
                              <!-- Blog Content -->
                              <div class="blog-content appo-blog">
                                  <!-- Blog Details -->
                                  <div class="blog-details">
<!--                                    <h3 class="blog-title py-2 py-sm-3">Signal messages, images, files, and other content are kept on your device.</h3>-->
                                    <p class="blog-title">
                                      <strong>
                                        Signal messages, images, files, and other content are kept on your device.</strong></p>
                                    <p class="blog-title py-2 py-sm-3">
                                      <strong>
                                      If you have an older device, choose the platform for transferring messages:</strong></p>
                                    <ul class="mb-3">
                                        <li>Android</li>
                                        <li>iOS</li>
                                        <li>Desktop</li>
                                    </ul>
                                    <p class="blog-title py-2 py-sm-3">
                                      <strong>If you have an older device, choose the platform for transferring messages:</strong></p>
                                    <ul class="mb-3">
                                      <li>Without your old device or your lost phone.</li>
                                      <li>Erased your phone.</li>
                                      <li>Uninstall Signal on your iPhone or iPad.</li>
                                      <li>Accidentally deleted a message or conversation.</li>
                                      <li>Switched between Android and iOS.</li>
                                      <li>Changed your phone number .</li>
                                      <li>Have a linked iPad or Computer.</li>
                                    </ul>
                                  </div>
                              </div>
                          </article>
                      </div>
                  </div>
              </div>
          </section>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">

  </script>
  
  <style scoped>
		ul li {
			list-style-type: disc;
			margin-left: 14px;
			margin-bottom: 12px;
		}
		a[href^="mailto:"] {
			color: blue;
			text-decoration: underline;
		}
  </style>
