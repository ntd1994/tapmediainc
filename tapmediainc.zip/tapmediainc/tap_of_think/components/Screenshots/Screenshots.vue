<template>
    <section id="screenshots" class="section screenshots-area ptb_100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- App Screenshot Slider Area -->
                    <div class="app-screenshots">
                        <!-- Single Screenshot Item -->
                        <div class="single-screenshot">
                            <img src="assets/img/screenshot_1.png" alt="">
                            <!-- Screenshots Overlay -->
                            <div class="screenshots-overlay">
                                <a href="assets/img/screenshot_1.png" data-fancybox="images"><i class="icofont-image"></i></a>
                            </div>
                        </div>
                        <!-- Single Screenshot Item -->
                        <div class="single-screenshot">
                            <img src="assets/img/screenshot_2.png" alt="">
                            <!-- Screenshots Overlay -->
                            <div class="screenshots-overlay">
                                <a href="assets/img/screenshot_2.png" data-fancybox="images"><i class="icofont-image"></i></a>
                            </div>
                        </div>
                        <!-- Single Screenshot Item -->
                        <div class="single-screenshot">
                            <img src="assets/img/screenshot_3.png" alt="">
                            <!-- Screenshots Overlay -->
                            <div class="screenshots-overlay">
                                <a href="assets/img/screenshot_3.png" data-fancybox="images"><i class="icofont-image"></i></a>
                            </div>
                        </div>
                        <!-- Single Screenshot Item -->
                        <div class="single-screenshot">
                            <img src="assets/img/screenshot_4.png" alt="">
                            <!-- Screenshots Overlay -->
                            <div class="screenshots-overlay">
                                <a href="assets/img/screenshot_4.png" data-fancybox="images"><i class="icofont-image"></i></a>
                            </div>
                        </div>
                        <!-- Single Screenshot Item -->
                        <div class="single-screenshot">
                            <img src="assets/img/screenshot_5.png" alt="">
                            <!-- Screenshots Overlay -->
                            <div class="screenshots-overlay">
                                <a href="assets/img/screenshot_5.png" data-fancybox="images"><i class="icofont-image"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {

}
</script>

<style>

</style>