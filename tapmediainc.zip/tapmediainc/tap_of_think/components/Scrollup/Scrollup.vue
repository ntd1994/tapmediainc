<template>
    <div id="scrollUp" title="Scroll To Top">
        <i class="icofont-bubble-up"></i>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>