<script setup lang="ts">

</script>

<template>
  <div class="miami">
    <Scrollup />
    <div class="all-area">
      <HeaderOne />
      <HeroOne />
      <PromoOne />
      <About />
      <Work />
      <Features />
      <LazyScreenshots />
      <Pricing />
      <Reviews />
      <Team />
      <Newsletter />
      <Download />
      <BlogsBlog />
      <Contact />
      <Footer />
    </div>
  </div>
</template>

<style scoped>

</style>