<template>
  <InnerPagesMaintenance />
</template>

<script>
</script>

<style>

</style>