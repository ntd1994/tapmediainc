<template>
  <InnerPagesNewsletter />
</template>

<script>
</script>

<style>

</style>