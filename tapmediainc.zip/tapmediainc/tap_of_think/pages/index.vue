<script setup lang="ts">

import Blog from "~/components/Blogs/Blog/Blog.vue";
import Screenshots from "~/components/Screenshots/Screenshots.vue";
import HeroTwo from "~/components/Hero/HeroTwo.vue";
import HeroThree from "~/components/Hero/HeroThree.vue";
import PromoTwo from "~/components/Promo/PromoTwo.vue";
import PromoThree from "~/components/Promo/PromoThree.vue";
</script>

<template>
  <div class="miami">
    <Scrollup />
    <div class="all-area">
      <HeaderThree />
      <HeroOne />
      <PromoTwo />
      <About />
      <Work />
      <Download />
      <Contact />
      <Footer />
    </div>
  </div>
</template>

<style scoped>

</style>