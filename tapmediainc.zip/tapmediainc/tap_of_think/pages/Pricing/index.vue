<template>
  <InnerPagesPricing />
</template>

<script>
</script>

<style>

</style>