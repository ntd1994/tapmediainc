<script setup lang="ts">


</script>

<template>
  <div class="miami">
    <Scrollup />
    <div class="all-area">
      <HeaderTwo />
      <PrivacyPolicyHero />
      <PrivacyPolicyContent />
      <Footer />
    </div>
  </div>
</template>

<style scoped>

</style>
