<script setup lang="ts">


</script>

<template>
  <div class="miami">
    <Scrollup />
    <div class="all-area">
      <HeaderTwo />
      <SupportHero
        page-name="Sealed sender"
      />
      <SupportSealedSenderContent />
      <Footer />
    </div>
  </div>
</template>

<style scoped>

</style>
