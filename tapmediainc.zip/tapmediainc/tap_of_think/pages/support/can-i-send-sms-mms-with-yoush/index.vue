<script setup lang="ts">


</script>

<template>
  <div class="miami">
    <Scrollup />
    <div class="all-area">
      <HeaderTwo />
      <SupportHero
        page-name="Can i send SMS/MMS with Yoush?"
      />
      <SupportCanISendSmsMmsWithYoushContent />
      <Footer />
    </div>
  </div>
</template>

<style scoped>

</style>
