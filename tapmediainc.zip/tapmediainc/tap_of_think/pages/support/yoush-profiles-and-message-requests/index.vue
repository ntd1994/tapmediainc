<script setup lang="ts">


</script>

<template>
  <div class="miami">
    <Scrollup />
    <div class="all-area">
      <HeaderTwo />
      <SupportHero
        page-name="Yoush Profiles And Message Requests"
      />
      <SupportYoushProfilesAndMessageRequestsContent />
      <Footer />
    </div>
  </div>
</template>

<style scoped>

</style>
