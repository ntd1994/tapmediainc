<template>
  <InnerPagesComingSoon />
</template>

<script>
</script>

<style>

</style>