<template>
  <InnerPagesThankYou />
</template>

<script>
</script>

<style>

</style>