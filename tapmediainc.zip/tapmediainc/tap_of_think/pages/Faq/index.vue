<template>
  <InnerPagesFaq />
</template>

<script>

</script>

<style>

</style>