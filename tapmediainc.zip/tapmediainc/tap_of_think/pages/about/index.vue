<template>
  <InnerPagesAbout />
</template>

<script>
</script>

<style>

</style>