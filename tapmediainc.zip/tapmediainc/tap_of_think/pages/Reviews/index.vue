<template>
  <InnerPagesReviews />
</template>

<script>
</script>

<style>

</style>