<template>
  <InnerPagesDownload />
</template>

<script>
</script>

<style>

</style>